
<div class="contenedor">
    <div class="parte ocultar-en-pequeño">
        <div class="cc">
            <h4><b>Sistema CRUD</b></h4>
            <img src="./public/img/crud.png" alt="Logo1" class="img-fluid" width="250px">
        </div>
    </div>
    <div class="parte">
        <div class="cc">
            <div class="ocultar-en-grande">
                <img src="./public/img/crud.png" alt="Logo2" class="img-fluid" width="200px">
            </div>
            <h4><b>Iniciar Sesión</b></h4>
            <hr>
            <form id="form-login" method="POST" action="controllers/LoginControllers.php">
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">
                        <i class="fa-regular fa-circle-user"></i>
                    </span>
                    <input type="text" name="usuario" id="usuario" class="form-control" placeholder="Ingrese Usuario ó Correo" required>
                </div>
                <div class="input-group mb-3">
                    <span class="input-group-text" id="basic-addon1">
                        <i class="fa-solid fa-key"></i>
                    </span>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Ingrese Contraseña" required>
                </div>
                <div class="input-group mb-3 justify-content-center">
                    <button class="btn btn-primary btn-sm">
                        <b>Acceder</b> <i class="fa-solid fa-right-to-bracket"></i>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
